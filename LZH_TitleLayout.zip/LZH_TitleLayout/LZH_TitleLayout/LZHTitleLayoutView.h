//
//  LZHTitleLayoutView.h
//  LZH_TitleLayout
//
//  Created by admin  on 2018/8/4.
//  Copyright © 2018年 刘中华. All rights reserved.
//

#import <UIKit/UIKit.h>

#pragma mark--图片、文字枚举样式
typedef NS_ENUM(NSUInteger, LZHEdgeInsetsStyle) {
    LZHEdgeInsetsStyleTop, // image在上，label在下
    LZHEdgeInsetsStyleLeft, // image在左，label在右
    LZHEdgeInsetsStyleBottom, // image在下，label在上
    LZHEdgeInsetsStyleRight // image在右，label在左
};

#pragma mark--按钮代理
@protocol LZHTitleLayoutViewDelegate <NSObject>

// 点击的按钮
-(void)clickBTnIndex:(NSInteger)index Title:(NSString *)title;
// 移除的按钮
-(void)removeBTnIndex:(NSInteger)removeIndex RemoveTitle:(NSString *)removeTitle;

@end


@interface LZHTitleLayoutView : UIView

/**
 frame : view本身frame
 titleArr : 标题名称，图片和标题同命名
 linkNumber : 行数（横向有几行）
 columnsNumber : 列数 （纵向有几列）
 style : 内容图片、文字的样式
 space : 内容图片、文字的间隙
 */
-(instancetype)initWithFrame:(CGRect)frame TitleArr:(NSArray*)titleArr LineNumber:(NSInteger)linkNumber ColumnsNumber:(NSInteger)columnsNumber EdgeInsetsStyle:(LZHEdgeInsetsStyle)style ImageTitleSpace:(CGFloat)space;

@property(nonatomic,assign)id<LZHTitleLayoutViewDelegate>delegate ;

@end
