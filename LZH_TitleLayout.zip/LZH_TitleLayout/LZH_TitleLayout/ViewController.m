//
//  ViewController.m
//  LZH_TitleLayout
//
//  Created by admin  on 2018/8/4.
//  Copyright © 2018年 刘中华. All rights reserved.
//

#import "ViewController.h"
#import "LZHTitleLayoutView.h"

@interface ViewController ()<LZHTitleLayoutViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//样式1 ：6个元素、2行、4列、图上文下、图文间隙10pt
    NSArray * titleArr = @[@"埃菲尔铁塔",@"埃及金字塔",@"比萨斜塔",@"迪拜帆船酒店",@"富士山",@"凯旋门"] ;
    LZHTitleLayoutView * titleLayoutView = [[LZHTitleLayoutView alloc]initWithFrame:CGRectMake(0, 20, 375, 250) TitleArr:titleArr LineNumber:2 ColumnsNumber:4 EdgeInsetsStyle:LZHEdgeInsetsStyleTop ImageTitleSpace:10];
    titleLayoutView.delegate = self ;
    [self.view addSubview:titleLayoutView];
    
    
//样式2 ：2个元素、1行、2列、图左文右、图文间隙5pt
    NSArray * titleArrTwo = @[@"长城",@"悉尼歌剧院"] ;
    LZHTitleLayoutView * titleLayoutViewTwo = [[LZHTitleLayoutView alloc]initWithFrame:CGRectMake(40, 300, 300, 60) TitleArr:titleArrTwo LineNumber:1 ColumnsNumber:2 EdgeInsetsStyle:LZHEdgeInsetsStyleLeft ImageTitleSpace:5];
    titleLayoutViewTwo.delegate = self ;
    [self.view addSubview:titleLayoutViewTwo];
    
    
//样式3 ：9个元素、3行、3列、图右文左、图文间隙0pt
    NSArray * titleArrThree = @[@"长城",@"悉尼歌剧院",@"泰姬陵",@"埃菲尔铁塔",@"埃及金字塔",@"比萨斜塔",@"迪拜帆船酒店",@"富士山",@"凯旋门"] ;
    LZHTitleLayoutView * titleLayoutViewThree = [[LZHTitleLayoutView alloc]initWithFrame:CGRectMake(0, 390, 375, 250) TitleArr:titleArrThree LineNumber:3 ColumnsNumber:3 EdgeInsetsStyle:LZHEdgeInsetsStyleRight ImageTitleSpace:0];
    titleLayoutViewThree.delegate = self ;
    [self.view addSubview:titleLayoutViewThree];
    
}

#pragma mark -- 点击的按钮事件
-(void)clickBTnIndex:(NSInteger)index Title:(NSString *)title{
    NSLog(@"点击：%ld---%@",index,title) ;
}

#pragma mark -- 移除的按钮事件
-(void)removeBTnIndex:(NSInteger)removeIndex RemoveTitle:(NSString *)removeTitle{
    NSLog(@"移除：%ld---%@",removeIndex,removeTitle) ;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
