//
//  LZHTitleLayoutView.m
//  LZH_TitleLayout
//
//  Created by admin  on 2018/8/4.
//  Copyright © 2018年 刘中华. All rights reserved.
//

#import "LZHTitleLayoutView.h"
#define kMaxX(X) CGRectGetMaxX(X)
#define kMaxY(Y) CGRectGetMaxY(Y)

// 这里的值可以适情况修改，不会影响到按钮内部内容图片、文字的大小、间距
#define Margin 0   // 行_列间距
#define LinkStartMargin 0   // 每行首列起始间距
#define ColumnsStartMargin 0   // 首行全列起始间距

@interface LZHTitleLayoutView()
// 内容所需宽度、高度
@property(nonatomic,assign)CGFloat viewW;
@property(nonatomic,assign)CGFloat viewH ;
// 内容数组
@property(nonatomic,strong)NSMutableArray * titleArr ;
// 行
@property(nonatomic,assign)NSInteger linkNumber ;
// 列
@property(nonatomic,assign)NSInteger columnsNumber ;
// 图片、文字位置样式
@property(nonatomic,assign)LZHEdgeInsetsStyle style ;
// 图片、文字间隙
@property(nonatomic,assign)CGFloat space ;
// 记录按钮宽度
@property(nonatomic,assign)CGFloat recordBtnW ;
// 移除按钮
@property(nonatomic,strong)UIButton * removeBtn ;
// 取消按钮
@property(nonatomic,strong)UIButton * cancelBtn ;
// 记录需要移除的按钮
@property(nonatomic,strong)UIButton * needRemoveBtn ;
// 保存按钮数组
@property(nonatomic,strong)NSMutableArray * btnArr ;

@end

@implementation LZHTitleLayoutView

-(instancetype)initWithFrame:(CGRect)frame TitleArr:(NSArray*)titleArr LineNumber:(NSInteger)linkNumber ColumnsNumber:(NSInteger)columnsNumber EdgeInsetsStyle:(LZHEdgeInsetsStyle)style ImageTitleSpace:(CGFloat)space{
   self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor] ;
        //附值
        self.viewW = self.frame.size.width ;
        self.viewH = self.frame.size.height ;
        self.titleArr = [NSMutableArray arrayWithArray:titleArr] ;
        self.linkNumber = linkNumber ;
        self.columnsNumber = columnsNumber ;
        self.style = style ;
        self.space = space ;
        
        //添加内容控件
        [self creatUI];
    
        //强行把规定范围外的剪掉
        self.clipsToBounds = YES ;
    }
    return self;
}


-(void)creatUI{
    //初始控件X、Y
    CGFloat btnX = 0;
    CGFloat btnY = 0;
    
    //计算控件W、H
    /*
     每个控件的宽度 = 需求总宽度 / (列数 + 1)*间距，再除以列数
     */
    CGFloat btnW = (self.viewW- (self.columnsNumber + 1) * Margin) / self.columnsNumber;
    self.recordBtnW = btnW ;
    /*
     每个控件的高度 = 需求总高度 / (行数 + 1)*间距，再除以行数
     */
    CGFloat btnH = ((self.viewH - ColumnsStartMargin) - (self.linkNumber + 1) * Margin) / self.linkNumber;
    
    for (int i=0; i<self.titleArr.count; i++) {
        UIButton * bgBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        //间隙 + 当前列数的值（总数取余得到） * （间隙 + 宽度）
        btnX = Margin + (i % self.columnsNumber) * (Margin + btnW);
        //间隙 + 当前行数的值（总数整除得到） * （间隙 + 高度)+首行起始距离
        btnY = Margin + (i / self.columnsNumber) * (Margin + btnH) + ColumnsStartMargin;
        //背景
        bgBtn.backgroundColor = [UIColor colorWithRed: arc4random_uniform(256)/255.0 green:arc4random_uniform(256)/255.0 blue:arc4random_uniform(256)/255.0 alpha:1];
        bgBtn.tag = i ;
//        bgBtn.clipsToBounds = YES ;
        //设置位置
        bgBtn.frame = CGRectMake(btnX+LinkStartMargin, btnY, btnW, btnH);
        //事件
        [bgBtn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
        //添加图片、文字
        [self addImageTitleToBtn:bgBtn index:i btnW:btnW btnH:btnH];
        //添加按钮，并保存到数组
        [self addSubview:bgBtn];
        [self.btnArr addObject:bgBtn];
        
        //创建添加长按手势，设置最短长按时间为0.8
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(btnLong:)];
        longPress.minimumPressDuration = 0.8;
        [bgBtn addGestureRecognizer:longPress];
    }
}

#pragma mark--添加图片、文字
-(void)addImageTitleToBtn:(UIButton *)btn index:(NSInteger)i btnW:(CGFloat)btnW btnH:(CGFloat)btnH{
    //创建图片控件
    UIImageView * iconImg = [[UIImageView alloc]initWithImage:[UIImage imageNamed:self.titleArr[i]]] ;
    //创建文字控件
    UILabel * titleLabel = [[UILabel alloc]init];
    titleLabel.text = self.titleArr[i] ;
    titleLabel.textColor = [UIColor whiteColor] ;
    titleLabel.font = [UIFont systemFontOfSize:15] ;
    titleLabel.textAlignment = 1 ;
    titleLabel.lineBreakMode = NSLineBreakByTruncatingMiddle; //中间位置省略号
    
    CGFloat iconImgX ;
    CGFloat iconImgY ;
    CGFloat titleX ;
    CGFloat titleY ;
    CGFloat titleW ;
    CGFloat titleH = 20 ;
    switch (self.style) {
        case LZHEdgeInsetsStyleTop: //图片在上，文字在下
            iconImgX = (btnW-iconImg.frame.size.width)/2 ;
            iconImgY = (btnH-iconImg.frame.size.height-self.space-titleH)/2 ;
            titleX = 0 ;
            titleY = iconImgY+kMaxY(iconImg.frame)+self.space ;
            titleW = btnW ;
            break;
            
        case LZHEdgeInsetsStyleLeft: ////图片在左，文字在右
            titleW = [self calculateRowWidth:self.titleArr[i]] ;
            iconImgX = (btnW-iconImg.frame.size.width-titleW-self.space)/2 ;
            iconImgY = (btnH-iconImg.frame.size.height)/2 ;
            titleX = iconImgX+kMaxX(iconImg.frame)+self.space ;
            titleY = (btnH-titleH)/2 ;
            break;
            
        case LZHEdgeInsetsStyleBottom://图片在下，文字在上
            titleX = 0 ;
            titleY = (btnH-iconImg.frame.size.height-self.space-titleH)/2 ;
            titleW = btnW ;
            iconImgX = (btnW-iconImg.frame.size.width)/2 ;
            iconImgY = titleY+titleH+self.space ;
            break;
            
        case LZHEdgeInsetsStyleRight://图片在右，文字在左
            titleW = [self calculateRowWidth:self.titleArr[i]] ;
            titleX = (btnW-titleW-self.space-iconImg.frame.size.width)/2 ;
            titleY = (btnH-titleH)/2 ;
            iconImgX = titleX+titleW+self.space ;
            iconImgY = (btnH-iconImg.frame.size.height)/2 ;
            break;
            
        default:
            break;
    }
    
    //设置位置
        iconImg.frame = CGRectMake(iconImgX, iconImgY, iconImg.frame.size.width, iconImg.frame.size.height);
        titleLabel.frame = CGRectMake(titleX, titleY, titleW, titleH) ;
    //添加
        [btn addSubview:iconImg];
        [btn addSubview:titleLabel];
}

#pragma mark--按钮的点击事件
-(void)clickBtn:(UIButton *)sender{
    NSInteger index = sender.tag ;
    if ([self.delegate respondsToSelector:@selector(clickBTnIndex:Title:)]) {
        [self.delegate clickBTnIndex:index Title:self.titleArr[index]];
    }
}

#pragma mark--计算文字宽度 （文字大小若改动，此处请自行修改）
- (CGFloat)calculateRowWidth:(NSString *)string {
    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:15]};  //指定字号
    CGRect rect = [string boundingRectWithSize:CGSizeMake(0, 20)/*计算宽度时要确定高度*/ options:NSStringDrawingUsesLineFragmentOrigin |
                   NSStringDrawingUsesFontLeading attributes:dic context:nil];
    return rect.size.width;
}

#pragma mark--按钮的长按事件
-(void)btnLong:(UILongPressGestureRecognizer *)gestureRecognizer{
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        //获取点击的按钮
        UIButton * btn = (UIButton*)gestureRecognizer.view ;
//        NSLog(@"--%ld",btn.tag) ;
        //记录长按的按钮是那个
        self.needRemoveBtn = btn ;
        //0.5内缩放操作
        [UIView animateWithDuration:0.5 animations:^{
            btn.transform = CGAffineTransformScale(btn.transform, 0.85, 0.85);
        }completion:^(BOOL finished) {
            //缩放之后摇摆三次
//            CABasicAnimation *SwingAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
//            SwingAnimation.fromValue = [NSNumber numberWithFloat:-0.05];
//            SwingAnimation.toValue = [NSNumber numberWithFloat:0.05];
//            SwingAnimation.duration = 1.2;
//            SwingAnimation.repeatCount = 3;
//            SwingAnimation.autoreverses = YES;
//            [btn.layer addAnimation:SwingAnimation forKey:@"animateLayer"];
            //添加移除、取消按钮
            [btn addSubview:self.removeBtn];
            [btn addSubview:self.cancelBtn];
        }];
    }
}

#pragma mark--移除按钮操作事件
-(void)clickRemove{
    NSInteger removeIndex = self.needRemoveBtn.tag ;
    //移除的事件
    if ([self.delegate respondsToSelector:@selector(removeBTnIndex:RemoveTitle:)]) {
        [self.delegate removeBTnIndex:removeIndex RemoveTitle:self.titleArr[removeIndex]];
    }
    //移除按钮
   [self.needRemoveBtn removeFromSuperview];
    for (int i=0; i<self.btnArr.count; i++) {
        UIButton * btn = self.btnArr[i] ;
        [btn removeFromSuperview];
    }
    //移除元素
    [self.titleArr removeObjectAtIndex:removeIndex];
    //重置内容
    [self creatUI];
}

#pragma mark--取消按钮操作事件
-(void)clickCancel{
    [self.removeBtn removeFromSuperview];
    [self.cancelBtn removeFromSuperview];
    [UIView animateWithDuration:0.5 animations:^{
        self.needRemoveBtn.transform = CGAffineTransformIdentity;
    }];
}

#pragma mark--懒加载
-(UIButton *)removeBtn{
    if (!_removeBtn) {
        _removeBtn = [[UIButton alloc]initWithFrame:CGRectMake(-7, -7, 20, 20)];
        [_removeBtn setTitle:@"X" forState:UIControlStateNormal];
        _removeBtn.backgroundColor = [UIColor redColor] ;
        [_removeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _removeBtn.titleLabel.font = [UIFont systemFontOfSize:15] ;
        _removeBtn.layer.cornerRadius = 10 ;
        _removeBtn.clipsToBounds = YES ;
        [_removeBtn addTarget:self action:@selector(clickRemove) forControlEvents:UIControlEventTouchUpInside];
    }
    return _removeBtn ;
}


-(UIButton *)cancelBtn{
    if (!_cancelBtn) {
        _cancelBtn = [[UIButton alloc]initWithFrame:CGRectMake(self.recordBtnW-16, -7, 30, 20)];
        [_cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
        _cancelBtn.backgroundColor = [UIColor orangeColor] ;
        [_cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _cancelBtn.titleLabel.font = [UIFont systemFontOfSize:11] ;
        _cancelBtn.layer.cornerRadius = 10 ;
        _cancelBtn.clipsToBounds = YES ;
        [_cancelBtn addTarget:self action:@selector(clickCancel) forControlEvents:UIControlEventTouchUpInside];
    }
    return _cancelBtn ;
}

-(NSMutableArray *)btnArr{
    if (!_btnArr) {
        _btnArr = [NSMutableArray array] ;
    }
    return _btnArr ;
}


@end
